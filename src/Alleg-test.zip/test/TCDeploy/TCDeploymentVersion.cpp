/////////////////////////////////////////////////////////////////////////////
// TCDeploymentVersion.cpp : Implementation of the TCDeploymentVersion class.

#include "pch.h"
#include "TCDeploy.h"
#include "TCDeploymentVersion.h"


/////////////////////////////////////////////////////////////////////////////
// TCDeploymentVersion

TC_OBJECT_EXTERN_IMPL(TCDeploymentVersion)

