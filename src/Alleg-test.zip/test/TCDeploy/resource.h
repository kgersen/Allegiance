//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TCDeploy.rc
//
#define IDR_TCDeployment                100
#define IDR_TCDeploymentProcess         101
#define IDS_SYNTAX_9X                   101
#define IDS_SYNTAX_NT                   102
#define IDR_AccessPermission_9X         102
#define IDS_LAUNCH_CMDLINE              103
#define IDS_E_CMDLINE                   104
#define IDS_STRING105                   105
#define IDR_TCDeploymentVersion         106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         3000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
