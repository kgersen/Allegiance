#pragma once

/////////////////////////////////////////////////////////////////////////////
// This file should contain the include files for all source code-based
// libraries used in the project. Any corresponding CPP files for the
// libraries should be placed in SrcInc.cpp.
//

#include <TCAtl.h>
#include <..\TCAtl\PropertyClass.h>
#include <..\TCAtl\TCNullStreamImpl.h>
#include <..\TCAtl\ObjectMap.h>

