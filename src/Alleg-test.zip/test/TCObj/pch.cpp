/////////////////////////////////////////////////////////////////////////////
// pch.cpp : source file that includes just the standard includes
//  TCObj.pch will be the pre-compiled header
//  pch.obj will contain the pre-compiled type information

#include "pch.h"

#ifdef _ATL_STATIC_REGISTRY
  #include <statreg.h>
  #include <statreg.cpp>
#endif

#include <atlimpl.cpp>
#include <atlwin.cpp>

