//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TCObj.rc
//
#define IDR_TCStrings                   100
#define IDR_TCMarshalByValue            101
#define IDR_TCNullStream                102
#define IDR_TCPropBagOnRegKey           103
#define IDR_REGISTRY1                   2000
#define IDR_TCUtility                   2000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2001
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         3000
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
