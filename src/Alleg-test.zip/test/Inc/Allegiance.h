#ifndef __Allegiance_h__
#define __Allegiance_h__

/////////////////////////////////////////////////////////////////////////////

#include <utility.h>
#include <..\engine\engine.h>
#include <..\effect\effect.h>
#include <..\igc\igc.h>
#include <..\Zone\Zone.h>
#include <..\zone\zauth.h>
#include <..\igc\mapmakerigc.h>
#include <messagesAll.h>
#include <messages.h>
#include <messagesLC.h>
#include <networkgame.h>
#include <..\clintlib\clintlib.h>
#include <..\clintlib\AutoDownload.h>
#include <..\drones\actionlib.h>
#include <..\igc\shipigc.h>


/////////////////////////////////////////////////////////////////////////////

#endif // !__Allegiance_h__
